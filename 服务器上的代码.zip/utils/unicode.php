<?php
    header('Access-Control-Allow-Origin:*');  
    header('Access-Control-Allow-Methods:*');
    header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$content = $_REQUEST['content'];
	// $content = '&#21941;';

	function unicodeDecode($data){
        function replace_unicode_escape_sequence($match)
        {
            return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
        }

        $rs = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $data);
        return $rs;
    }

	$result = unicodeDecode($content);
	
	echo $result;
?>