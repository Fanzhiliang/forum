<?php
return [
	'smtpserver' => "ssl://smtp.aliyun.com", //SMTP服务器
  	'smtpserverport' => 465, //SMTP服务器端口
  	'smtpusermail' => "zhongerliang@aliyun.com", //SMTP服务器的用户邮箱
  	'smtpuser' => "zhongerliang@aliyun.com", //SMTP服务器的用户帐号
  	'smtppass' => "47789.321", //SMTP服务器的用户密码
];
?>