<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$pageNo = intval($body['pageNo']);
	$floorId = intval($body['floor_id']);
	$send = ['code' => 500,'data' => ['message' => '']];
	if($pageNo<1){$pageNo = 1;}

	if($floorId>0){
		include_once('../controller/Dao.php');
		$dao = new Dao();

		$totalCount = $dao->getReplyCountById($floorId);
		if($pageNo>0 && $totalCount>0 && $pageNo<=$totalCount){
			$replyData = $dao->getReplyList($floorId,$pageNo);
			include_once('../utils/strToTags.php');
			if(count($replyData['list']) > 0){
				$list = [];
				foreach ($replyData['list'] as $reply) {
					$replyUser = $dao->getUserById($reply['user_id']);
					$ableDelete = $user['user_id']==$replyUser['user_id']?$reply['reply_id']:0;
					$list[] = [
						'replyUser' => $replyUser,
						'value' => strToTags(json_decode($reply['value'],true),false),
						'time' => $reply['time'],
						'reply_id' => $reply['reply_id'],
						'user_id' => $reply['user_id']
					];
				}
				$send['code'] = 200;
				$send['data']['list'] = $list;
				$send['data']['pageNo'] = $replyData['pageNo'];
				$send['data']['totalPage'] = $replyData['totalPage'];
			}else{
				$send['data']['message'] = '无更多回复';
			}
		}else{
			$send['data']['message'] = '数据错误';
		}
	}else{
		$send['data']['message'] = '数据不完整';
	}
	echo json_encode($send);
	
?>