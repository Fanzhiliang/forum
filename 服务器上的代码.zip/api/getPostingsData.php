<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$pageNo = intval($body['pageNo']);
	$keywords = $body['keywords'];
	$send = ['code' => 500,'data' => ['message' => '']];

	if($pageNo < 1){$pageNo = 1;}

	include_once('../controller/Dao.php');
	include_once('../utils/strToTags.php');
	$dao = new Dao();
	$postingsData = $dao->getPostingsList($keywords,$pageNo);

	for($i=0;$i<count($postingsData['list']);$i++) {
		$post = $postingsData['list'][$i];
		$user = $dao->getUserById($post['user_id']);
		if($user['user_id'] > 0){
			$postingsData['list'][$i]['username'] = $user['name'];
			$postingsData['list'][$i]['userHeadImg'] = $user['head_img'];
			$floorOne = $dao->getFloorOne($post['postings_id']);
			$postingsData['list'][$i]['floorOneValue'] = strToTags(json_decode($floorOne['value'],true),false,true,false);
		}
	}

	$send['code'] = 200;
	$send['data'] = $postingsData;

	echo json_encode($send);
?>