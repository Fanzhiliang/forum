<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$name = $_POST['body']['value'];
	$send = ['code'=>500,'data'=>['message'=>'']];
	if(strlen(trim($name))>0){
		include_once('../controller/Dao.php');
		$dao = new Dao();
		$result = $dao->isExistName($name);
		if($result == 0){//不存在
			$send['code'] = 404;
			$send['data']['message'] = '呢称未被注册';
		}else if($result == 1){//存在
			$send['code'] = 200;
			$send['data']['message'] = '呢称已被注册';
		}
	}else{
		$send['data']['message'] = '数据不完整';
	}
	echo json_encode($send);
?>