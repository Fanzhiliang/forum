<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$token = trim($body['token']);
	$postingsId = intval($body['postings_id']);
	$send = ['code' => 500,'data' => ['message' => '']];

	if(strlen($token)>0 && $postingsId>0){
		include_once('../controller/Dao.php');
		$dao = new Dao();
		$user = $dao->getUserByToken($token);
		//获得收藏信息
		$keepData = $dao->getKeepByUserId($user['user_id']);
		$keep = null;
		foreach ($keepData['list'] as $k) {//找到要删除的贴子
			if($k['postings_id'] == $postingsId){
				$keep = $k;
				break;
			}
		}
		if($keep == null){
			$send['data']['message'] = '你还没收藏,请刷新';
			echo json_encode($send);
			die;
		}
		$deleteRes = $dao->deleteKeep($keep['keep_id']);
		if(isset($deleteRes['user_id']) && isset($deleteRes['postings_id'])){
			$send['code'] = 200;
			$send['data']['message'] = '取消收藏成功';
		}
	}else{
		$send['data']['message'] = '数据不完整';
	}
	echo json_encode($send);
?>