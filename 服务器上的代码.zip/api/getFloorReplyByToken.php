<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$token = trim($body['token']);
	$pageNo = intval($body['pageNo']);
	if($pageNo<1){$pageNo=1;}
	$send = ['code' => 500,'data' => ['message' => '']];
	include_once('../controller/Dao.php');
	$dao = new Dao();
	$user = $dao->getUserByToken($token);

	if($user['user_id'] > 0){
		include_once('../utils/strToTags.php');
		$FloorReplyData = $dao->getFloorReplyByUserId($user['user_id'],$pageNo);

		for($i=0;$i<count($FloorReplyData['list']);$i++){
			$obj = $FloorReplyData['list'][$i];
			$postings = $dao->getPostingByPostingsId($obj['postings_id']);
			$FloorReplyData['list'][$i]['postings'] = !!$postings?$postings:[];
			$FloorReplyData['list'][$i]['value'] = strToTags(json_decode($obj['value'],true),false,false);
			$floorNo = 1;
			if($obj['type'] == 'reply'){
				$floor = $dao->getFloorById($obj['floor_id']);
				$floorNo = $floor['floor_no'];
				$floor['value'] = strToTags(json_decode($floor['value'],true),false,false);
				$FloorReplyData['list'][$i]['floor'] = $floor;
			}else{
				$floorNo = $obj['floor_no'];
			}

			$list = $dao->getAllFLoorByPostingsId($postings['postings_id']);
			$FloorReplyData['list'][$i]['_floorNo'] = $floorNo;
			for($j = 0;$j<count($list);++$j){
				if($list[$j]['floor_no'] == $floorNo){
					$pageSize = $dao->getPageSize();
					++$j;
					$FloorReplyData['list'][$i]['_pageNo'] = $j%$pageSize==0 ? intval($j/$pageSize) : intval($j/$pageSize)+1;
					break;
				}
			}
			
		}

		$send['code'] = 200;
		$send['data'] = $FloorReplyData;
	}else{
		$send['data']['message'] = '还没登录,请登录';
	}

	echo json_encode($send);
?>