<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$postingsId = $body['postings_id'];
	$pageNo = $body['pageNo'];
	$send = ['code' => 500,'data' => ['message' => '']];
	if($pageNo < 1){$pageNo = 1;}

	if($postingsId > 0){
		include_once('../controller/Dao.php');
		include_once('../utils/strToTags.php');
		$dao = new Dao();
		$floorData = $dao->getFloorList($postingsId,$pageNo);

		for($i=0;$i<count($floorData['list']);$i++){
			$floor = $floorData['list'][$i];
			$floorData['list'][$i]['value'] = strToTags(json_decode($floor['value'],true));
			$floorUser = $dao->getUserById($floor['user_id']);
			if($floorUser['user_id'] > 0){
				$floorUser['password'] = '';//删除密码属性 这个很关键
				$floorData['list'][$i]['floorUser'] = $floorUser;

				$replyData = $dao->getReplyList($floor['floor_id'],1);
				for($j=0;$j<count($replyData['list']);$j++){
					$reply = $replyData['list'][$j];
					$replyData['list'][$j]['value'] = strToTags(json_decode($reply['value'],true),false);
					$replyUser = $dao->getUserById($reply['user_id']);
					if($replyUser['user_id'] > 0){
						$replyUser['password'] = '';//删除密码属性 这个很关键
						$replyData['list'][$j]['replyUser'] = $replyUser;
					}
				}
				$floorData['list'][$i]['replyData'] = $replyData;
			}
		}
		$send['code'] = 200;
		$send['data'] = $floorData;
	}else{
		$send['data']['message'] = '数据错误或贴子不存在';
	}
	echo json_encode($send);
?>