<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$email = $_POST['body']['value'];
	$send = ['code'=>500,'data'=>['message'=>'']];
	if($email && strlen(trim($email))>0){
		include_once('../controller/Dao.php');
		$dao = new Dao();
		$result = $dao->isExistEmail($email);
		if($result == 0){//不存在
			$send['code'] = 404;
			$send['data']['message'] = '邮箱未被注册';
		}else if($result == 1){//存在
			$send['code'] = 200;
			$send['data']['message'] = '邮箱已被注册';
		}
	}else{
		$send['data']['message'] = '数据不完整';
	}
	echo json_encode($send);
?>