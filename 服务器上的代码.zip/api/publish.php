<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$get = $_POST['body'];
	$token = trim($get['token']);
	$send = ['code' => 500,'data' => ['message' => '']];
	include_once('../controller/Dao.php');
	$dao = new Dao();
	$user = $dao->getUserByToken($token);

	if($user['user_id']>0){
		if(isset($get['title'])){//发表帖子
			$send['data']['message'] = '发表失败';
			$postingsId = $dao->insertPostings($user['user_id'],$get['title']);
			if($postingsId > 0){//添加到贴子表成功
				$result = $dao->insertFloor($postingsId,$user['user_id'],json_encode($get['value'],JSON_UNESCAPED_UNICODE));
				if($result){
					$send['code'] = 200;
					$send['data']['message'] = 'success';
					$send['data']['href'] = '/';
				}
			}
		}else if(!isset($get['title']) && isset($get['postings_id'])){//回复帖子
			$result = $dao->insertFloor($get['postings_id'],$user['user_id'],json_encode($get['value'],JSON_UNESCAPED_UNICODE));
			if($result){
				$send['code'] = 200;
				$send['data']['message'] = 'success';
				// $send['data']['href'] = '/postings/'.$get['postings_id'];
				$thatFloor = $dao->getFloorById($result);
				$list = $dao->getAllFLoorByPostingsId($get['postings_id']);
				$pageNo = 1;
				for($i = 0;$i<count($list);++$i){
					if($list[$i]['floor_no'] == $thatFloor['floor_no']){
						$pageSize = $dao->getPageSize();
						++$i;
						$pageNo = $i%$pageSize==0 ? intval($i/$pageSize) : intval($i/$pageSize)+1;
						break;
					}
				}
				$send['data']['action'] = '/postings/'.$thatFloor['postings_id'];
				$send['data']['params'] = [
					'floor_no'=>$thatFloor['floor_no'],
					'pageNo'=>$pageNo
				];
			}
		}else if(!isset($get['title']) && isset($get['floor_id'])){//回复楼层
			$result = $dao->insertReply($user['user_id'],$get['floor_id'],json_encode($get['value'],JSON_UNESCAPED_UNICODE));
			if($result){
				$send['code'] = 200;
				$send['data']['message'] = 'success';
				$thatFloor = $dao->getFloorById($get['floor_id']);
				$list = $dao->getAllFLoorByPostingsId($thatFloor['postings_id']);
				$pageNo = 1;
				for($i = 0;$i<count($list);++$i){
					if($list[$i]['floor_no'] == $thatFloor['floor_no']){
						$pageSize = $dao->getPageSize();
						++$i;
						$pageNo = $i%$pageSize==0 ? intval($i/$pageSize) : intval($i/$pageSize)+1;
						break;
					}
				}
				$send['data']['action'] = '/postings/'.$thatFloor['postings_id'];
				$send['data']['params'] = [
					'floor_no'=>$thatFloor['floor_no'],
					'pageNo'=>$pageNo
				];
			}
		}else{
			$send['data']['message'] = '数据不完整';
		}
	}else{
		$send['code'] = 404;
		$send['data']['message'] = '登录信息有误,请重新登陆';
	}
	echo json_encode($send);
?>
