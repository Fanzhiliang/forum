<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$postingsId = $_POST['body']['postings_id'];
	$send = ['code' => 500,'data' => ['message' => '']];

	if($postingsId > 0){
		include_once('../controller/Dao.php');
		$dao = new Dao();
		$postings = $dao->getPostingByPostingsId($postingsId);
		if(!!$postings && $postings['is_ban'] == 0){
			$send['code'] = 200;
			$send['data']['postings'] = $postings;
		}else{
			$send['code'] = 404;
			$send['data']['message'] = '贴子不存在或被删除';
		}
	}else{
		$send['data']['message'] = '数据不完整或错误';
	}
	echo json_encode($send);
?>