<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$token = trim($body['token']);
	$floorId = trim($body['floor_id']);
	$send = ['code' => 500,'data' => ['message' => '']];
	include_once('../controller/Dao.php');
	$dao = new Dao();
	$user = $dao->getUserByToken($token);

	if($user['user_id']>0){
		include_once('../utils/strToTags.php');
		$floorData = $dao->getFloorById($floorId);//楼层信息
		$floorUser = $dao->getUserById($user['user_id']);////发表楼层用户信息
		$replyData = $dao->getAllReplyByFloorId($floorId);//所有回复

		$floorData['value'] = strToTags(json_decode($floorData['value'],true));

		for($i=0;$i<count($replyData['list']);$i++){
			$reply = $replyData['list'][$i];
			$replyUser = $dao->getUserById($reply['user_id']);
			$replyData['list'][$i]['value'] = strToTags(json_decode($reply['value'],true),false);
			$replyData['list'][$i]['replyUser'] = $replyUser;
		}

		$send['code'] = 200;
		$send['data'] = [
			'floorData' => $floorData,
			'floorUser' => $floorUser,
			'replyData' => $replyData
		];	
	}else{
		$send['code'] = 404;
		$send['data']['message'] = '登录信息有误,请重新登陆';
	}
	echo json_encode($send);
?>