<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$token = trim($body['token']);
	$send = ['code' => 500,'data' => ['message' => '']];

	if(strlen($token)>0){
		include_once('../controller/Dao.php');
		$dao = new Dao();
		$user = $dao->getUserByToken($token);
		if($user['user_id']>0){
			$send['code'] = 200;
			$send['data']['user'] = $user;
		}else{
			$send['data']['message'] = '数据错误或过时';
		}
	}else{
		$send['code'] = 404;
		$send['data']['message'] = '未登录,请重新登录';
	}
	echo json_encode($send);
?>