<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$token = trim($body['token']);
	$pageNo = intval($body['pageNo']);
	if($pageNo<1){$pageNo=1;}
	$send = ['code' => 500,'data' => ['message' => '']];
	include_once('../controller/Dao.php');
	$dao = new Dao();
	$user = $dao->getUserByToken($token);

	if($user['user_id'] > 0){
		$postingsData = $dao->getPostingsByUserId($user['user_id'],$pageNo);
		$send['code'] = 200;
		$send['data'] = $postingsData;
	}else{
		$send['data']['message'] = '还没登录,请登录';
	}
	echo json_encode($send);
?>