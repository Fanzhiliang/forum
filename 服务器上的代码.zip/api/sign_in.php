<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$token = trim($_POST['body']['token']);
	$send = ['code' => 500,'data' => ['message' => '']];

	if(strlen($token)>0){
		include_once('../controller/Dao.php');
		$dao = new Dao();
		$user = $dao->getUserByToken($token);
		$newUser = $dao->signIn($user['user_id']);
		if($newUser['user_id']>0){
			$send['code'] = 200;
			$send['data']['message'] = 'success';
			$send['data']['user'] = $newUser;
		}else if($newUser['user_id']==0){
			$send['data']['message'] = '已经签到';
		}
	}else{
		$send['data']['message'] = '数据不完整';
	}
	echo json_encode($send);
?>