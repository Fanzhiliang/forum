<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$get = $_POST['body'];
	$token = trim($get['token']);
	$send = ['code' => 500,'data' => ['message' => '']];
	include_once('../controller/Dao.php');
	$dao = new Dao();
	$user = $dao->getUserByToken($token);

	if($user['user_id'] > 0){
		if(isset($get['reply_id'])){
			$replyData = $dao->getReplyByUserId($user['user_id']);
			foreach ($replyData['list'] as $reply) {
				if($reply['user_id'] == $user['user_id']){
					$result = $dao->deleteReply($get['reply_id']);
					if($result){
						$send['code'] = 200;
						$send['data']['message'] = 'success';
					}
					echo json_encode($send);
					die;
				}
			}
			$send['data']['message'] = '该回复不属于你';
		}else if(isset($get['floor_id'])){
			$floorData = $dao->getFloorByUserId($user['user_id']);
			foreach ($floorData['list'] as $floor) {
				if($floor['user_id'] == $user['user_id']){
					$result = $dao->deleteFloor($get['floor_id']);
					if($result){
						$send['code'] = 200;
						$send['data']['message'] = 'success';
					}
					echo json_encode($send);
					die;
				}
			}
			$send['data']['message'] = '该楼层不属于你';
		}else if(isset($get['postings_id'])){
			$postData = $dao->getPostingsByUserId($user['user_id']);
			foreach ($postData['list'] as $post) {
				if($post['user_id'] == $user['user_id']){
					$result = $dao->deletePostings($get['postings_id']);
					if($result){
						$send['code'] = 200;
						$send['data']['message'] = 'success';
					}
					echo json_encode($send);
					die;
				}
			}
			$send['data']['message'] = '该贴子不属于你';
		}else{
			$send['data']['message'] = '数据不完整';
		}
	}else{
		$send['data']['message'] = '用户数据错误';
	}
	echo json_encode($send);
?>