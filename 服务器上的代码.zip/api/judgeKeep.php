<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$token = trim($body['token']);
	$postingsId = intval($body['postings_id']);
	$send = ['code' => 500,'data' => ['message' => '']];

	if(strlen($token)>0 && $postingsId>0){
		include_once('../controller/Dao.php');
		$dao = new Dao();
		$user = $dao->getUserByToken($token);
		$keep = $dao->isKeepByUserId($user['user_id'],$postingsId);
		$send['code'] = 200;
		$send['data']['isKeep'] = $keep['postings_id']==$postingsId;
	}else{
		$send['data']['message'] = '数据错误:token,贴子信息错误';
	}
	echo json_encode($send);
?>