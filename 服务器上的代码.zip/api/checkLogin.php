<?php
	header('Access-Control-Allow-Origin:*');  
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers: X-HTTP-Method-Override, Content-Type, x-requested-with, Authorization');

	$body = $_POST['body'];
	$account = trim($body['account']);
	$password = trim($body['password']);
	$send = ['code' => 500,'data' => ['message' => '']];

	if(strlen($account)>0 && strlen($password)>0){
		include_once('../controller/Dao.php');
		$dao = new Dao();
		$user = $dao->checkLogin($account,$password);
		switch ($user['user_id']) {
			case 0:
				$send['data']['message'] = '用户不存在';
				break;
			case -1:
				$send['data']['message'] = '密码错误';
				break;
			case -2:
				$send['data']['message'] = '用户为激活';
				break;
			default:
				if($user['user_id'] >0){
					$send['code'] = 200;
					$send['data']['token'] = $user['token'];
				}
				break;
		}
	}else{
		$send['data']['message'] = '数据不完整';
	}

	echo json_encode($send);
?>