<?php
	include_once('sendPost.php');
	$HTTP_TYPE = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
	$PREFIX = $HTTP_TYPE.$_SERVER['SERVER_NAME'];//地址前缀
	date_default_timezone_set("PRC");
	$token = trim($_GET['token']);
	if(strlen($token) > 0){
		include_once('Dao.php');
		$dao = new Dao();
		$user = $dao->getUserByToken($token);
		if($user['user_id']<1){
			header("location:http://localhost:8080/#/updatePas?message=".urlencode('数据错误'));
		}
		if($user['status'] === 1){
			header("location:http://localhost:8080/#/login?message=".urlencode('账号已验证'));
		}
		if(time() <= intval($user['token_time'])+24*60*60){//24小时内验证
			if($dao->updateUserStatus($user['user_id'])){
				header("location:http://localhost:8080/#/login?message=".urlencode('验证成功,请登录'));
			}else{
				header("location:http://localhost:8080/#/updatePas?message=".urlencode('修改数据时发生错误'));
			}
		}else{//超时验证
			header("location:http://localhost:8080/#/updatePas?message=".urlencode('请求过时'));
		}
	}else{
		header("location:http://localhost:8080/#/updatePas?message=".urlencode('token错误或账号不存在'));
	}
?>	